import json
import requests
import os
import boto3
import time

# Retrieve the EC2_ID environment variable as a list
instance_ids = os.environ.get('EC2_ID').split(',')
BOT_TOKEN = os.environ.get('TELEGRAM_TOKEN')
ec2 = boto3.client('ec2', region_name='us-east-1')

def lambda_handler(event, context):
    try:
        request_body = json.loads(event['body'])
        print(request_body)
        command = request_body['message']['text']
        print(command)

        # Split the command into action and instance ID
        command_parts = command.split()
        action = command_parts[0].lower()  # e.g., 'start' or 'stop'

        print(f"Action: {action}")
        if len(command_parts) > 1:
            instance_id = command_parts[1]  # Get the instance ID
            print(f"Instance ID: {instance_id}")

            if action == 'stop' and instance_id in instance_ids:
                ec2.stop_instances(InstanceIds=[instance_id])
                response_text = f"Stopping instance: {instance_id}"
                
            elif action == 'start' and instance_id in instance_ids:
                ec2.start_instances(InstanceIds=[instance_id])
                time.sleep(30)  # Wait for the instance to start
                response = ec2.describe_instances(InstanceIds=[instance_id])
                public_ip = response['Reservations'][0]['Instances'][0]['PublicIpAddress']
                n_public_ip = 'ec2-' + public_ip + '.compute-1.amazonaws.com'
                response_text = f"Started instance: {instance_id}\nPublic IP: {n_public_ip}"
            else:
                response_text = "Invalid instance ID or action."

            # Sending response to Telegram
            BOT_CHAT_ID = request_body['message']['chat']['id']
            send_text = f'https://api.telegram.org/bot{BOT_TOKEN}/sendMessage?chat_id={BOT_CHAT_ID}&parse_mode=HTML&text={response_text}'
            requests.get(send_text)

            return {
                'statusCode': 200
            }
        else:
            return {
                'statusCode': 400,
                'body': json.dumps('Please provide a command and instance ID.')
            }

    except Exception as e:
        print(f"Error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps('An error occurred while processing your request.')
        }
